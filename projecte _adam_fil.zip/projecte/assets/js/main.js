$(function() {
    // El código dentro de esta función se ejecutará una vez que el DOM esté listo
    // Puedes colocar aquí todas las inicializaciones y manipulaciones del DOM que necesites
});
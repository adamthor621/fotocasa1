<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "iestacio";
$password = "iestacio";
$dbname = "fotocasa";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Construir la consulta basada en los filtros proporcionados por el usuario
$sql_filtros = "SELECT * FROM pisos WHERE 1";

if(isset($_POST['provincia']) && $_POST['provincia'] !== '') {
    $provincia = $_POST['provincia'];
    $sql_filtros .= " AND provincia_id = $provincia";
}

if(isset($_POST['tipo_vivienda']) && $_POST['tipo_vivienda'] !== '') {
    $tipo_vivienda = $_POST['tipo_vivienda'];
    $sql_filtros .= " AND tipo_vivienda_id = $tipo_vivienda";
}

// Agregar más condiciones según sea necesario para los otros filtros...

// Ejecutar la consulta
$result_filtros = $conn->query($sql_filtros);
?>

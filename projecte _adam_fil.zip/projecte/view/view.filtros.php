<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscador de Pisos</title>
    <link rel="icon" type="image/jpg" href="assets/img/icono.ico">
    <link rel="stylesheet" href="assets/css/filtros.css">
</head>
<body>
    <h1>Buscador de Pisos</h1>
    <form method="post" action="inmuebles.php">

        <label for="provincia">Provincia:</label>
        <select name="provincia" id="provincia">
            <option value="">Todas</option>
            <?php
            // Conexión a la base de datos
            $servername = "localhost";
            $username = "iestacio";
            $password = "iestacio";
            $dbname = "fotocasa";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Verificar la conexión
            if ($conn->connect_error) {
                die("Error de conexión: " . $conn->connect_error);
            }

            // Obtener provincias
            $sql_provincias = "SELECT * FROM pisos INNER JOIN provincias on pisos.provincia=provincias.nombre_provincia;";
            $result_provincias = $conn->query($sql_provincias);
            while($row_provincia = $result_provincias->fetch_assoc()) {
                echo "<option value='" . $row_provincia['id'] . "'>" . $row_provincia['nombre_provincia'] . "</option>";
            }
            ?>
        </select>

        <label for="tipo_vivienda">Tipo de pisos:</label>
        <select name="tipo_vivienda" id="tipo_vivienda">
            <option value="">Todos</option>
            <?php
            // Obtener tipos de pisos
            $sql_tipos_pisos = "SELECT DISTINCT * FROM pisos  INNER JOIN tipo_pisos on pisos.id_tipo=tipo_pisos.codigo_tipo;";
            $result_tipos_pisos = $conn->query($sql_tipos_pisos);
            while($row_tipo_piso = $result_tipos_pisos->fetch_assoc()) {
                echo "<option value='" . $row_tipo_piso['id'] . "'>" . $row_tipo_piso['tipo'] . "</option>";
            }
            ?>
        </select>

        <label for="extras">Extras:</label>
        <select name="extras" id="extras">
            <option value="">Cualquiera</option>
            <?php
            // Obtener extras
            $sql_extras = "SELECT * FROM extras";
            $result_extras = $conn->query($sql_extras);
            while($row_extra = $result_extras->fetch_assoc()) {
                echo "<option value='" . $row_extra['id'] . "'>" . $row_extra['nombre'] . "</option>";
            }
            ?>
        </select>

        <label for="banos">Baños:</label>
        <select name="banos" id="banos">
            <option value="">Cualquiera</option>
            <option value="1">1 baño</option>
            <option value="2">2 baños</option>
            <option value="3">3 baños</option>
        </select>

        <label for="busqueda">Búsqueda:</label>
        <input type="text" name="busqueda" id="busqueda" placeholder="Palabra clave">

        <button type="submit">Buscar</button>
    </form>

    <h2>Resultados:</h2>
<?php
   if (mysqli_num_rows($result_filtros) > 0) {
    while($row_piso = mysqli_fetch_assoc($result_filtros)) {
    echo "<div class='piso'>";
            echo "<h3>" . $row_piso["titulo"] . "</h3>";
            echo "<p>Precio: $" . $row_piso["precio"] . "</p>";
            echo "<p>Habitaciones: " . $row_piso["habitaciones"] . "</p>";
            echo "<p>Baños: " . $row_piso["banos"] . "</p>";
            echo "<p>Provicia: " . $row_piso["provincia"] . "</p>";
            echo "<p>disponibilidad: " . $row_piso["disponibilidad"] . "</p>";
            echo "<p> imagen: " . $row_piso["imagen_url"]. "</p>";
            // Mostrar más detalles del piso según sea necesario
            echo "</div>";
    }
}

    // Tu cdigo PHP para la conexión a la base de datos y la consulta de filtros aquí...

    // Definir el límite de resultados por página
    $limit = 2;

    // Calcular el offset para la consulta según la página actual
    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $offset = ($page - 1) * $limit;

    // Consulta para obtener resultados con límite y offset
    $sql_filtros = "SELECT * FROM tu_tabla WHERE tus_filtros LIMIT $limit OFFSET $offset";
    $result_filtros = $conn->query($sql_filtros);

    // Mostrar resultados
    if ($result_filtros->num_rows > 0) {
        while($row_piso = $result_filtros->fetch_assoc()) {
            echo "<div class='piso'>";
            echo "<h3>" . $row_piso["titulo"] . "</h3>";
            echo "<p>Precio: $" . $row_piso["precio"] . "</p>";
            echo "<p>Habitaciones: " . $row_piso["habitaciones"] . "</p>";
            echo "<p>Baños: " . $row_piso["banos"] . "</p>";
            echo "<p>Provicia: " . $row_piso["provincia"] . "</p>";
            echo "<p>disponibilidad: " . $row_piso["disponibilidad"] . "</p>";
            echo "<p> imagen: " . $row_piso["imagen_url"]. "</p>";
            echo "</div>";
        }
    }

    // Agregar botón para ver más resultados si hay más de 2 resultados en total
    $sql_total = "SELECT COUNT(*) AS total FROM tu_tabla WHERE tus_filtros";
    $result_total = $conn->query($sql_total);
    $row_total = $result_total->fetch_assoc();
    $total = $row_total['total'];

    // Calcular el número total de páginas
    $pages = ceil($total / $limit);

    // Mostrar el botón de siguiente si hay más de una página
    if ($pages > 1 && $page < $pages) {
        echo "<a href='tu_pagina.php?page=" . ($page + 1) . "'>Siguiente</a>";
    }
?>

?>

</body>
</html>

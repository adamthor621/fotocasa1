
<!DOCTYPE html>
<html lang="en">
<head>
<link href="../assets/css/style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<header>
<img name ='logo' src="./imagenes/logo.jpeg" width="50" height="50"> <br>
<nav>
    <ul>
      <li><a href="#">Compra</a></li>
      <li><a href="#">Ventas</a></li>
      <li><a href="#">Servicios</a></li>
      <li><a href="#">>Alquilar</a></li>
    </ul>
</nav>

</header>
<body>

</body>
</html>
<?php
include './model/model.filtros.php';

$conexionBD = new ConexionBD();

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $sql_filtros = "SELECT * FROM pisos WHERE 1=1"; // Consulta base

    if(isset($_GET['provincia']) && !empty($_GET['provincia'])) {
        $provincia = $_GET['provincia'];
        $sql_filtros .= " AND provincia_id = $provincia";
    }

    if(isset($_GET['tipo_vivienda']) && !empty($_GET['tipo_vivienda'])) {
        $tipo_vivienda = $_GET['tipo_vivienda'];
        $sql_filtros .= " AND tipo_vivienda_id = $tipo_vivienda";
    }

    if(isset($_GET['extras']) && !empty($_GET['extras'])) {
        $extras = $_GET['extras'];
        $sql_filtros .= " AND piso_id IN (SELECT piso_id FROM piso WHERE extra_id = $extras)";
    }

    // Agregar más filtros según sea necesario

    $result_filtros = $conexionBD->filtrarPisos($sql_filtros);
}

$conexionBD->cerrarConexion();
include './view/view.filtros.php';
?>

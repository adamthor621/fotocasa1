<?php
class ConexionBD {
    private $servername = "localhost";
    private $username = "iestacio";
    private $password = "iestacio";
    private $dbname = "fotocasa";
    private $conn;

    public function __construct() {
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
        if ($this->conn->connect_error) {
            die("Error de conexión: " . $this->conn->connect_error);
        }
    }

    public function obtenerProvincias() {
        $sql_provincias = "SELECT * FROM provincias";
        return $this->conn->query($sql_provincias);
    }

    public function obtenerTiposPisos() {
        $sql_tipos_pisos = "SELECT * FROM tipo_pisos";
        return $this->conn->query($sql_tipos_pisos);
    }

    public function obtenerExtras() {
        $sql_extras = "SELECT * FROM extras";
        return $this->conn->query($sql_extras);
    }

    public function filtrarPisos($sql_filtros) {
        return $this->conn->query($sql_filtros);
    }

    public function cerrarConexion() {
        $this->conn->close();
    }
}
?>
